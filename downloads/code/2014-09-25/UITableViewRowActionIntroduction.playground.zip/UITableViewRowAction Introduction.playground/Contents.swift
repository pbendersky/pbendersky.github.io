//: Playground - noun: a place where people can play

import UIKit
import XCPlayground

/*:
 # UITableViewRowAction Introduction
 
 iOS 7 saw the introduction of a new style for the swipe to delete in table view cells. The entire cell content was placed in a `UIScrollView`, and swiping would reveal the red Delete button. iOS Mail (and only that app) also sported an additional More menu item. This API, however was private.
 
 In iOS 8, Apple finally made this API public for all of us to use, in the form of edit actions and `UITableViewRowAction`.
 
 ## Usage
 
 In order to provide your `UITableViewCell`s with actions, you need to implement a `UITableViewDelegate` method:
````
func tableView(tableView: UITableView, editActionsForRowAtIndexPath indexPath: NSIndexPath) -> [UITableViewRowAction]?
````
 The method retuns an _array_ of actions. The order is of course important: the first item in the Array will be the rightmost (or leftmost on RTL user interfaces) item when you swipe the cell.
 
 A sample implementation follows:
 */

extension TableViewController {
    
    override public func tableView(tableView: UITableView, editActionsForRowAtIndexPath indexPath: NSIndexPath) -> [UITableViewRowAction]? {
        let deleteClosure = { (action: UITableViewRowAction!, indexPath: NSIndexPath!) -> Void in
            print("Delete closure called")
        }
        
        let moreClosure = { (action: UITableViewRowAction!, indexPath: NSIndexPath!) -> Void in
            print("More closure called")
        }
        
        let deleteAction = UITableViewRowAction(style: .Default, title: "Delete", handler: deleteClosure)
        let moreAction = UITableViewRowAction(style: .Normal, title: "More", handler: moreClosure)
        
        return [deleteAction, moreAction]
    }
    
}

/*:
 
 As you can see you need to return an array of `UITableViewRowAction` objects. `UITableViewRowAction.init` receives three parameters:
 
 - `style`: either `.Normal` or `.Default`. `.Normal` doesn't have a color, similar to the `More` button in iOS 7 Mail, and `.Default` is the standard destructive action, with the red background color.
 - `title`: the label that will be shown to the user when swiping the row.
 - `handler`: a closure (or block) with the handler that will be called when the action is selected by the user. The handler receives two parameters: the `action` itself, and the `indexPath`. Sadly, the handler doesn't give you the `UITableView` as a parameter, so your handler needs to get a reference to that by other means.

 If you take a look at the code under Sources, you'll notice that besides `tableView:editActionsForRowAtIndexPath:` you need to override `tableView:commitEditingStyle:forRowAtIndexPath:`, even though you can leave it blank. If the method is not present, the actions won't show up on swipe.
 */

let viewController = TableViewController()
viewController.view.frame = CGRect(x: 0, y: 0, width: 320, height: 480)

XCPlaygroundPage.currentPage.liveView = viewController.view
